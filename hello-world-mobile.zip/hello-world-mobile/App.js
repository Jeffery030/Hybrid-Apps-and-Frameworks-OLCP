import { Text, View } from 'react-native';

export default function App() {
  return (
    <View>
      <Text>
        Hi, my name is Jefferson Fraire, and I am a mobile developer
      </Text>
    </View>
  );
}
